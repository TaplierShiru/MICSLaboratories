from .gun_states import GunStates

"""
Collect position where player can walk
Also where are all path between all states

"""

# (X, Y) - coords on the frame
BAD_CENTER = [20, 20]
MY_ROOM_CENTER = [120, 120]
CLOTHS_PLACE = [175, 125]

CORIDORE_1 = [120, 250]
CORIDORE_2 = [325, 250]
CENTER_ENTER_ROOM = [325, 335]

TOILER = [325, 100]
KICTHEN = [100, 335]
EXIT = [325, 900]

# None - mean finish
ONE2TWO = [
    [BAD_CENTER, MY_ROOM_CENTER],
    None
]
ONE2THREE = [
    [BAD_CENTER, BAD_CENTER],
    None
]

TWO2SIX = [
    [MY_ROOM_CENTER, CORIDORE_1],
    [CORIDORE_1, CORIDORE_2],
    [CORIDORE_2, TOILER],
    None
]
TWO2ONE = [
    [MY_ROOM_CENTER, BAD_CENTER],
    None
]

THREE2TWO = ONE2TWO
THREE2ONE = [None]

FOUR2FREE = [
    [CLOTHS_PLACE, BAD_CENTER],
    None
]
FOUR2SEVEN = [
    [CLOTHS_PLACE, MY_ROOM_CENTER],
    [MY_ROOM_CENTER, CORIDORE_1],
    [CORIDORE_1, CORIDORE_2],
    [CORIDORE_2, CENTER_ENTER_ROOM],
    [CENTER_ENTER_ROOM, KICTHEN],
    None
]
FOUR2FINISH = [
    [CLOTHS_PLACE, MY_ROOM_CENTER],
    [MY_ROOM_CENTER, CORIDORE_1],
    [CORIDORE_1, CORIDORE_2],
    [CORIDORE_2, CENTER_ENTER_ROOM],
    [CENTER_ENTER_ROOM, EXIT],
    None
]
FOUR2ONE = [
    [MY_ROOM_CENTER, BAD_CENTER],
    None
]

FIVE2FOUR = [
    [CLOTHS_PLACE, CLOTHS_PLACE],
    None
]
FIVE2THREE = [
    [CLOTHS_PLACE, MY_ROOM_CENTER],
    [MY_ROOM_CENTER, BAD_CENTER],
    None
]
FIVE2FINISH = FOUR2FINISH
FIVE2ONE = FOUR2ONE

SIX2FIVE = [
    [TOILER, CORIDORE_2],
    [CORIDORE_2, CORIDORE_1],
    [CORIDORE_1, MY_ROOM_CENTER],
    [MY_ROOM_CENTER, CLOTHS_PLACE],
    None
]
SIX2FOUR = SIX2FIVE
SIX2THREE = [
    [CORIDORE_2, CORIDORE_1],
    [CORIDORE_1, MY_ROOM_CENTER],
    [MY_ROOM_CENTER, BAD_CENTER],
    None
]
SIX2ONE = SIX2THREE

SEVEN2FINISH = [
    [KICTHEN, CENTER_ENTER_ROOM],
    [CENTER_ENTER_ROOM, EXIT],
    None
]
SEVEN2THREE = [
    [CENTER_ENTER_ROOM, CORIDORE_2],
    [CORIDORE_2, CORIDORE_1],
    [CORIDORE_1, MY_ROOM_CENTER],
    [MY_ROOM_CENTER, BAD_CENTER],
    None
]
SEVEN2ONE = SEVEN2THREE

# Keep all possibile path in the dict,
# easy to get, easy to use!
STORAGE_PATHS = {
    GunStates.STATE_1_SLEEP: {
        GunStates.STATE_2_WAKEUP: ONE2TWO,
        GunStates.STATE_3_SLEEP_5MIN_MORE: ONE2THREE
    },
    GunStates.STATE_2_WAKEUP: {
        GunStates.STATE_3_SLEEP_5MIN_MORE: TWO2ONE,
        GunStates.STATE_6_WASHFACE: TWO2SIX,
        GunStates.STATE_1_SLEEP: TWO2ONE
    },
    GunStates.STATE_3_SLEEP_5MIN_MORE: {
        GunStates.STATE_2_WAKEUP: THREE2TWO,
        GunStates.STATE_1_SLEEP: THREE2ONE
    },
    GunStates.STATE_4_TAKE_CLOTHS: {
        GunStates.STATE_3_SLEEP_5MIN_MORE: FOUR2FREE,
        GunStates.STATE_7_EAT: FOUR2SEVEN,
        GunStates.STATE_8_GO_TO_UNIVERSITY: FOUR2FINISH,
        GunStates.STATE_1_SLEEP: FOUR2ONE
    },
    GunStates.STATE_5_TAKE_SCHOOLBAG: {
        GunStates.STATE_4_TAKE_CLOTHS: FIVE2FOUR,
        GunStates.STATE_8_GO_TO_UNIVERSITY: FIVE2FINISH,
        GunStates.STATE_1_SLEEP: FIVE2ONE,
        GunStates.STATE_3_SLEEP_5MIN_MORE: FIVE2THREE
    },
    GunStates.STATE_6_WASHFACE: {
        GunStates.STATE_4_TAKE_CLOTHS: SIX2FOUR,
        GunStates.STATE_5_TAKE_SCHOOLBAG: SIX2FIVE,
        GunStates.STATE_1_SLEEP: SIX2ONE,
        GunStates.STATE_3_SLEEP_5MIN_MORE: SIX2THREE
    },
    GunStates.STATE_7_EAT: {
        GunStates.STATE_8_GO_TO_UNIVERSITY: SEVEN2FINISH,
        GunStates.STATE_1_SLEEP: SEVEN2ONE,
        GunStates.STATE_3_SLEEP_5MIN_MORE: SEVEN2THREE
    },
    GunStates.STATE_8_GO_TO_UNIVERSITY: None,
}

