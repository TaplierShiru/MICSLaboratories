from .gun_states import GunStates

"""
Some parameters to write them into text box

"""

TEXT_DATA = {
    GunStates.STATE_1_SLEEP: "Вася спит...",
    GunStates.STATE_2_WAKEUP: "Вася проснулся!",
    GunStates.STATE_3_SLEEP_5MIN_MORE: "Вася говорит: `Посплю еще пять минут...`",
    GunStates.STATE_4_TAKE_CLOTHS: "Вася идет одеваться",
    GunStates.STATE_5_TAKE_SCHOOLBAG: "Вася идет собирать портфель",
    GunStates.STATE_6_WASHFACE: "Вася идет умываться",
    GunStates.STATE_7_EAT: "Вася идет завтракать",
    GunStates.STATE_8_GO_TO_UNIVERSITY: "Вася идет в универ!",
    GunStates.STATE_FINISH: "Конец истории!"

}